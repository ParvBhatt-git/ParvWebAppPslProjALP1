package com.psl.repository;

import org.springframework.data.repository.CrudRepository;
import com.psl.entity.PatientTreatment;

public interface IPatientTreatmetRepo extends CrudRepository<PatientTreatment, Integer>{
}//interface
