package com.psl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientTreatmentRestProjApplicationTests {

	@Test
	void contextLoads() {
	}

}
